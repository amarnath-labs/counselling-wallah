function normalizeText(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[./(),_-]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function normalizeArray(value) {
  if (!Array.isArray(value)) return [];
  return value
    .map(normalizeText)
    .filter(Boolean);
}

export function normalizeCareerProfile(input = {}) {
  return {
    stage: normalizeText(input.stage),
    currentClass: normalizeText(input.currentClass),
    board: normalizeText(input.board),
    stream: normalizeText(input.stream),
    subjects: normalizeArray(input.subjects),
    targetExams: normalizeArray(input.targetExams),
    degree: normalizeText(input.degree || input.highestQualification),
    specialization: normalizeText(input.specialization || input.branch),
    branch: normalizeText(input.branch || input.specialization),
    collegeYear: normalizeText(input.collegeYear),
    graduationYear: normalizeText(input.graduationYear),
    goal: normalizeText(input.goal),
    skills: normalizeArray(input.skills),
    experience: normalizeText(input.experience),
    currentStatus: normalizeText(input.currentStatus),
  };
}

export function profileToTags(profile) {
  return [
    profile.stage,
    profile.currentClass,
    profile.board,
    profile.stream,
    profile.degree,
    profile.specialization,
    profile.branch,
    profile.collegeYear,
    profile.goal,
    profile.experience,
    profile.currentStatus,
    ...profile.subjects,
    ...profile.targetExams,
    ...profile.skills,
  ].filter(Boolean);
}
