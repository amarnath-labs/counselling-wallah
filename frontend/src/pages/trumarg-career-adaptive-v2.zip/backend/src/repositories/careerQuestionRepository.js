import { pool } from '../db/pool.js';

function mapQuestion(row) {
  return {
    id: row.id,
    stage: row.stage,
    section: row.section,
    trait: row.trait,
    purpose: row.purpose,
    text: row.text,
    options: row.options_json || [],
    degrees: row.degrees || [],
    branches: row.branches || [],
    streams: row.streams || [],
    subjects: row.subjects || [],
    skills: row.skills || [],
    goals: row.goals || [],
    tags: row.tags || [],
    priority: row.priority,
    weight: Number(row.weight || 1),
  };
}

export async function getQuestionByIds(ids = []) {
  if (!ids.length) return [];

  const { rows } = await pool.query(
    `
      SELECT *
      FROM career_questions
      WHERE id = ANY($1::text[])
    `,
    [ids]
  );

  return rows.map(mapQuestion);
}

export async function getCandidateQuestions({
  stage,
  excludeIds = [],
  limit = 120,
}) {
  const { rows } = await pool.query(
    `
      SELECT *
      FROM career_questions
      WHERE active = TRUE
        AND stage = $1
        AND NOT (id = ANY($2::text[]))
      ORDER BY priority ASC, id ASC
      LIMIT $3
    `,
    [stage, excludeIds, limit]
  );

  return rows.map(mapQuestion);
}

export async function getQuestionMap(ids = []) {
  const questions = await getQuestionByIds(ids);
  return new Map(questions.map((question) => [question.id, question]));
}
