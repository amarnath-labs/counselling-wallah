# Counselling Wallah — Phase 1 Frontend Refactor

Counselling Wallah is a frontend refactor of the existing single-file HTML prototype. The prototype remains preserved under `prototype/counselling-wallah-v2.html` and is the source of truth for the current visual language and product flow.

## Migration plan followed
1. Inspect the complete prototype: screens, styles, state, navigation, data and mock boundaries.
2. Preserve the original prototype as a backup/reference.
3. Reuse the existing React/Vite frontend rather than introducing unnecessary framework churn.
4. Split the monolithic data into focused modules.
5. Keep route-level screens and reusable components separated.
6. Keep recommendation, counselling and payment logic outside UI components.
7. Test the available static/build checks and document anything that cannot be executed in this environment.

## Architecture
```text
Counselling-Wallah/
├── prototype/                 # original HTML reference
├── frontend/
│   ├── src/
│   │   ├── components/        # reusable UI
│   │   ├── pages/             # route-level screens
│   │   ├── layouts/            # shared shell
│   │   ├── services/           # local/mock business logic seam
│   │   ├── data/               # focused demo/local datasets
│   │   ├── hooks/              # React state/context
│   │   ├── utils/              # input/security helpers
│   │   ├── styles/             # migrated CSS/theme
│   │   └── types/              # data-shape documentation
│   └── package.json
├── backend/README.md           # future phase only
└── database/README.md          # future phase only
```

## Run locally
```powershell
cd frontend
npm install
npm run dev
```

Build:
```powershell
npm run build
npm run preview
```

## Migrated functionality
- Homepage and rank-based quick search
- Exam selection/search
- Student profile
- Dream / Target / Safe / Backup recommendation buckets
- Result filters and sorting
- College detail tabs
- Compare up to five college/branch entries
- Choice-list add/remove/reordering
- Pricing page with demo payment only
- Session-only dashboard
- Sample counselling timeline
- Document checklist
- Desktop/tablet/mobile navigation

## Demo/mock boundaries
No backend, database, real authentication, real payment gateway, AI, or production recommendation engine is implemented in Phase 1. The recommendation service uses the prototype's local/demo rules. Fees, placements, some cutoffs, category adjustments and counselling dates remain explicitly demo/estimated where the prototype marks them that way.

## Future phases
1. Frontend architecture
2. Backend + PostgreSQL
3. Verified admission data
4. Real recommendation engine
5. Authentication + persistent dashboard
6. Admin panel
7. Payments
8. AI counsellor
