/** @typedef {{name:string, closingRank:number, closingRank2026?:number, round?:string, round2026?:string, source?:string, sourced?:boolean, fees:number, median:number, average:number, highest:number, placement:number}} Branch */
/** @typedef {{id:string,name:string,city:string,state:string,type:string,established:number,website:string,portal:string,branches:Branch[]}} College */
/** @typedef {{id:string,name:string,desc:string,active:boolean}} Exam */
/** @typedef {{rank:number,pct:string,year:string,category:string,gender:string,homeState:string,branches:string[],budget:number,type:string,hostel:string,prefState:string}} StudentProfile */
/** @typedef {{collegeId:string,college:College,branch:Branch,bucket:'dream'|'target'|'safe'|'backup',overall:number,breakdown:{rank:number,branch:number,budget:number,location:number}}} Recommendation */
/** @typedef {{collegeId:string,branchName:string}} Comparison */
/** @typedef {{collegeId:string,branchName:string}} ChoiceListItem */
/** @typedef {{name:string,date:string,status:'done'|'now'|'upcoming'}} CounsellingEvent */
