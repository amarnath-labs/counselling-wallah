import { COLLEGES } from '../data/colleges';
import { BRANCH_LIST } from '../data/branches';
import { BUCKET_META, CATEGORY_RELAXATION } from '../data/demoData';

export function computeResults(profile){
  const relax = CATEGORY_RELAXATION[profile.category] || 1;
  const rows=[];
  COLLEGES.forEach(college=>{
    if(profile.type!=='Both' && college.type!==profile.type) return;
    college.branches.forEach(branch=>{
      const effectiveClosing=Math.round(branch.closingRank*relax);
      const ratio=profile.rank/effectiveClosing;
      if(ratio>1.15) return;
      let bucket;
      if(ratio<=0.35) bucket='backup';
      else if(ratio<=0.65) bucket='safe';
      else if(ratio<=0.95) bucket='target';
      else bucket='dream';
      const rankScore=Math.max(0,Math.min(100,Math.round(100-Math.abs(ratio-0.6)*70)));
      const branchScore=(profile.branches.length===0 || profile.branches.includes(branch.name))?95:62;
      const budgetScore=branch.fees<=profile.budget?92:(branch.fees<=profile.budget*1.25?68:40);
      const locScore=(!profile.prefState || college.state===profile.prefState)?(college.state===profile.homeState?96:82):60;
      const overall=Math.round(rankScore*0.4+branchScore*0.25+budgetScore*0.2+locScore*0.15);
      rows.push({collegeId:college.id,college,branch,bucket,overall,breakdown:{rank:rankScore,branch:branchScore,budget:budgetScore,location:locScore}});
    });
  });
  return rows.sort((a,b)=>b.overall-a.overall);
}
export function filterAndSortResults(results, filters, profile){
  let rows=results.filter(r=>(!filters.branch||r.branch.name===filters.branch)&&(!filters.state||r.college.state===filters.state)&&(!filters.type||r.college.type===filters.type));
  const relax=CATEGORY_RELAXATION[profile.category]||1;
  const eff=r=>Math.round(r.branch.closingRank*relax);
  if(filters.sort==='fees') rows=[...rows].sort((a,b)=>a.branch.fees-b.branch.fees);
  else if(filters.sort==='rank') rows=[...rows].sort((a,b)=>Math.abs(profile.rank-eff(a))-Math.abs(profile.rank-eff(b)));
  else if(filters.sort==='placement') rows=[...rows].sort((a,b)=>b.branch.placement-a.branch.placement);
  else rows=[...rows].sort((a,b)=>b.overall-a.overall);
  return rows;
}
export function summarizeBuckets(rows){
  return rows.reduce((acc,r)=>({...acc,[r.bucket]:acc[r.bucket]+1}),{dream:0,target:0,safe:0,backup:0});
}
export { BRANCH_LIST, BUCKET_META };
