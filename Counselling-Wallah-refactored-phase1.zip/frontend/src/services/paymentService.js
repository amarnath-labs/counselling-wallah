export function runDemoPayment(amount, plan){
  return new Promise(resolve=>setTimeout(()=>resolve({amount,plan,status:'Successful',demo:true}),300));
}
