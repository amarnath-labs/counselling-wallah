// Phase 1 boundary: UI-only session behavior. No real authentication is implemented.
export function getDemoUser() {
  return { id: 'demo-student', name: 'Student', authenticated: true };
}

export function signOutDemo() {
  // Real auth/session invalidation belongs to the future backend phase.
  return { authenticated: false };
}
