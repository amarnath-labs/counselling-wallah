import { createContext,useContext,useMemo,useState } from 'react';
import { computeResults } from '../services/recommendationService';
import { getCollegeById } from '../services/collegeService';

const initialProfile={rank:18452,pct:'',year:'2026',category:'General',gender:'Male',homeState:'Maharashtra',branches:['CSE','IT'],budget:1000000,type:'Both',hostel:'Yes',prefState:''};
const AppContext=createContext(null);
export function AppStateProvider({children}){
 const [selectedExamId,setSelectedExamId]=useState('jee-main');
 const [profile,setProfile]=useState(initialProfile);
 const [results,setResults]=useState([]);
 const [compareList,setCompareList]=useState([]);
 const [choiceList,setChoiceList]=useState([]);
 const [currentCollegeId,setCurrentCollegeId]=useState(null);
 const [currentBranchIdx,setCurrentBranchIdx]=useState(0);
 const [cdTab,setCdTab]=useState('overview');
 const currentCollege=useMemo(()=>getCollegeById(currentCollegeId),[currentCollegeId]);
 const generateResults=nextProfile=>{const p=nextProfile||profile; setProfile(p); const r=computeResults(p); setResults(r); return r;};
 const openCollege=(id,branchName)=>{const c=getCollegeById(id); setCurrentCollegeId(id); setCurrentBranchIdx(Math.max(0,c?.branches.findIndex(b=>b.name===branchName)??0)); setCdTab('overview');};
 const addCompare=(collegeId,branchName)=>setCompareList(prev=>prev.length>=5||prev.some(x=>x.collegeId===collegeId&&x.branchName===branchName)?prev:[...prev,{collegeId,branchName}]);
 const addChoice=(collegeId,branchName)=>setChoiceList(prev=>prev.some(x=>x.collegeId===collegeId&&x.branchName===branchName)?prev:[...prev,{collegeId,branchName}]);
 const value={selectedExamId,setSelectedExamId,profile,setProfile,results,setResults,compareList,setCompareList,choiceList,setChoiceList,currentCollegeId,currentCollege,currentBranchIdx,setCurrentBranchIdx,cdTab,setCdTab,generateResults,openCollege,addCompare,addChoice};
 return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export const useAppState=()=>useContext(AppContext);
