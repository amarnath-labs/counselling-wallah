# Backend — Planned

No backend is implemented in this phase.

Planned responsibility:
- Authentication and authorization
- Server-side profile persistence
- Verified admission/cutoff data APIs
- Recommendation API when the logic moves server-side
- Counselling calendar updates
- Payment order creation and server-side verification
- Rate limiting and audit/security controls

The frontend must not treat this README as evidence that a backend exists.
