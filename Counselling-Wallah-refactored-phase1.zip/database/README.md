# Database — Planned

No database is implemented in this phase.

Potential future PostgreSQL domains:
- students / profiles
- exams
- colleges
- branches
- cutoff records by year/round/category/quota
- counselling events
- choice lists
- payment/order records

Verified admission data should be versioned and sourced so historical records remain auditable.
